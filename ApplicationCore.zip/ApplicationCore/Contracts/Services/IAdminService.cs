namespace ApplicationCore.Contracts.Services;

public class IAdminService
{
    
}