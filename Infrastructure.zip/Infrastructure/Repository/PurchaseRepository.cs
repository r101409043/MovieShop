namespace Infrastructure.Repository;

public class PurchaseRepository
{
    
}