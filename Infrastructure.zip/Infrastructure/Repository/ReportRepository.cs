namespace Infrastructure.Repository;

public class ReportRepository
{
    
}