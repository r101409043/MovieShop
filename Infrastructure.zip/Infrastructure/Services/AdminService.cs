namespace Infrastructure.Services;

public class AdminService
{
    
}